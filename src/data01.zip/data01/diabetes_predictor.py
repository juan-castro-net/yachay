from flask import Flask, jsonify, request
import joblib
import pandas as pd
from sklearn.preprocessing import MinMaxScaler as Scaler
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/predict', methods=['GET', 'POST'])
def predict():
	# load the model from disk
	filename = 'models/diabetes.model'
	svc = joblib.load(filename)

	# load the scaler from disk
	filename = 'models/scaler.scaler'
	scaler = joblib.load(filename)


	content = request.json
	print(content)
	NumTimesPrg = content['NumTimesPrg']
	PlGlcConc = content['PlGlcConc']
	BloodP = content['BloodP']
	SkinThick = content['SkinThick']
	TwoHourSerIns = content['TwoHourSerIns']
	BMI = content['BMI']
	DiPedFunc = content['DiPedFunc']
	Age = content['Age']

	"""
	# We create a new (fake) person having the three most correated values high
	NumTimesPrg = 6
	PlGlcConc = 168
	BloodP = 72
	SkinThick = 35
	TwoHourSerIns = 0
	BMI = 43.6
	DiPedFunc = 0.627
	Age = 65
	#HasDiabetes = 

	NumTimesPrg = 1
	PlGlcConc = 85
	BloodP = 66
	SkinThick = 29
	TwoHourSerIns = 0
	BMI = 26.6
	DiPedFunc = 0.351
	Age = 31
	"""

	new_df = pd.DataFrame([[NumTimesPrg, PlGlcConc, BloodP, SkinThick, TwoHourSerIns, BMI, DiPedFunc, Age]])
	# We scale those values like the others
	new_df_scaled = scaler.transform(new_df)

	# We predict the outcome
	prediction = svc.predict(new_df_scaled)
	
	diagnostic = prediction[0]

	return jsonify({'diabetes':str(diagnostic)})




if __name__ == '__main__':
    app.run()