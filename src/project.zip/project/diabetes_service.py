from flask import Flask, jsonify, request
from flask_cors import CORS
import joblib
import pandas as pd

app = Flask(__name__)
CORS(app)

@app.route("/")
def helloWorld():
  return "Hello, cross-origin-world!"

@app.route("/predict", methods=['POST'])
def predict():
    # load the model from disk
    filename = 'models/diabetes.model'
    svc = joblib.load(filename)

    filename = 'models/scaler.scaler'
    scaler = joblib.load(filename)

    json_data = request.json

    NumTimesPrg = json_data['NumTimesPrg']
    PlGlcConc = json_data['PlGlcConc']
    BloodP = json_data['BloodP']
    SkinThick = json_data['SkinThick']
    TwoHourSerIns = json_data['TwoHourSerIns']
    BMI = json_data['BMI']
    DiPedFunc = json_data['DiPedFunc']
    Age = json_data['Age']

    data = []
    data.append(NumTimesPrg)
    data.append(PlGlcConc)
    data.append(BloodP)
    data.append(SkinThick)
    data.append(TwoHourSerIns)
    data.append(BMI)
    data.append(DiPedFunc)
    data.append(Age)

    #[6, 168, 72, 35, 0, 43.6, 0.627, 65]
    # We create a new (fake) person having the three most correated values high
    new_df = pd.DataFrame([data])
    #new_df = pd.DataFrame([[6, 168, 72, 35, 0, 43.6, 0.627, 65]])
    #new_df = pd.DataFrame([[1, 85, 66, 29, 0, 26.6, 0.351, 31]])
    # We scale those values like the others
    new_df_scaled = scaler.transform(new_df)

    # We predict the outcome
    prediction = svc.predict(new_df_scaled)
    diagnostic = str(prediction[0])
    # A value of "1" means that this person is likley to have type 2 diabetes
    return jsonify({'HasDiabetes':str(diagnostic)})


if __name__ == "__main__":
    app.run()
