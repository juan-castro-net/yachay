package org.usco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

public class App {

	public static void main(String[] args) {
		
		Connection con1 = null;
		Statement stm1 = null;
		ResultSet rs1 = null;
		String sql = "";
		int affecteds = 0;
		
		String user = "sales100";
		String password = "sales100";
		String url = "jdbc:postgresql://localhost:5432/sales100";
		String className = "org.postgresql.Driver";
		
		try {
			// registrar el driver
			Class.forName(className);
			con1 = DriverManager.getConnection(url, user, password);
			stm1 = con1.createStatement();
			
			/*
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-08', " + 340000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-09', " + 280000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-10', " + 320000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-11', " + 300000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-12', " + 290000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-13', " + 310000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "insert into sales (date, sale)"; 
			sql += " values ('2019-11-14', " + 380000 + ")"; 
			affecteds = stm1.executeUpdate(sql);
			*/
			
			sql = "delete from sales where date = '2019-11-12'"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "update sales set sale = 350000 where date = '2019-11-10'"; 
			affecteds = stm1.executeUpdate(sql);
			
			sql = "select * from sales";
			rs1 = stm1.executeQuery(sql);
			
			while(rs1.next()) {
				int id = rs1.getInt("id");
				Timestamp date = rs1.getTimestamp("date");
				double sale = rs1.getDouble("sale");
				
				System.out.println(id + ", " + date + ", " + sale);		
			}
			
	
		}
		catch(Exception e) {
			System.out.println("Error: " +  e.toString());
		}
		
	}

}
