package org.usco;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataBase {
	
	public Connection getConnection() {
		Connection con1 = null;
		
		String user = "sales100";
		String password = "sales100";
		String url = "jdbc:postgresql://localhost:5432/sales100";
		String className = "org.postgresql.Driver";
		
		try {
			// registrar el driver
			Class.forName(className);
			con1 = DriverManager.getConnection(url, user, password);
		}
		catch(Exception e) {
			System.out.println("Error: " + e.toString());
		}
		
		return con1;
	}
}
