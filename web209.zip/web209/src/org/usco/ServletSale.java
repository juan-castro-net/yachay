package org.usco;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletSale
 */
@WebServlet("/ServletSale")
public class ServletSale extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletSale() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getTable(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}
	
	public void getTable(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		DataBase db1 = new DataBase();
		Connection con1 = null;
		Statement stm1 = null;
		ResultSet rs1 = null;
		String sql = "";
		
		try {
			con1 = db1.getConnection();
			stm1 = con1.createStatement();
			
			sql = "select * from sales";
			rs1 = stm1.executeQuery(sql);
			
			String actions = "<a href='forma.jsp?action=ADD&id=0" 
					+ "'>Add</a>";
			out.println(actions);
			
			String table = "<table>";
			table += "<tr><td>id</td><td>date</td><td>sale</td><td></td></tr>";
			while(rs1.next()) {
				int id = rs1.getInt("id");
				Timestamp date = rs1.getTimestamp("date");
				double sale = rs1.getDouble("sale");
				table += "<tr><td>" + id + "</td>";
				table += "<td>" + date + "</td>";
				table += "<td>" + sale + "</td>";
				actions = "<a href='forma.jsp?action=UPDATE&id=" 
						+ id + "'>Update</a>&nbsp;";
				actions += "<a href='forma.jsp?action=DELETE&id=" 
						+ id + "'>Delete</a>";
				table += "<td>" + actions + "</td>";
				table += "</tr>";
			}
			table += "</table>";
			
			out.println(table);
			
		}
		catch(Exception e) {
			System.out.println("Error: " +  e.toString());
		}
	}

}
