package org.usco.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.usco.utils.BaseDato;

/**
 * Servlet implementation class ServletProduct
 */
@WebServlet("/ServletProduct")
public class ServletProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		read(request, response);
	}

	private void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String category = request.getParameter("category");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String state = request.getParameter("state");
		
		String sql = "INSERT INTO product(";
	    sql += "category, name, price, state)";
	    sql += " VALUES (" + category + ",'" + name 
	    		+ "'," + price + "," + state + ")";
	    System.out.println(sql);
		
	    PrintWriter out = response.getWriter();
	    
		try {
			BaseDato basedato = new BaseDato();
			Connection con1 = basedato.getConnection();
			Statement stm1 = con1.createStatement();
			int inserteds = stm1.executeUpdate(sql);
			
			if (inserteds > 0) {
				out.println("<p>Operación ejecutada exitosamente.</p>");
			}
			else {
				out.println("<p>Error al ejecutar la operación.</p>");
			}
		} 
		catch (Exception e) {
			System.out.println("Error: " + e.toString());
			out.println("<p>Error al ejecutar la operación.</p>");
		}
	}
	
	private void read(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String sql = "SELECT id, category, name, price, state"; 
		sql += " FROM product order by name";
		
	    System.out.println(sql);
		
	    PrintWriter out = response.getWriter();
	    
		try {
			BaseDato basedato = new BaseDato();
			Connection con1 = basedato.getConnection();
			Statement stm1 = con1.createStatement();	
			ResultSet rs1 = stm1.executeQuery(sql);
			String html = "<table border='1'>";
			html += "<tr><td>id</td>";
			html += "<td>category</td>";
			html += "<td>name</td>";
			html += "<td>price</td>";
			html += "<td>state</td></tr>";
			
			while(rs1.next()) {
				int id = rs1.getInt("id");
				int category = rs1.getInt("category");
				String name = rs1.getString("name");
				double price = rs1.getDouble("price");
				int state = rs1.getInt("state");
				
				html += "<tr><td>" + id + "</td>";
				html += "<td>" + category + "</td>";
				html += "<td>" + name + "</td>";
				html += "<td>" + price + "</td>";
				html += "<td>" + state + "</td></tr>";
			}
			html += "</table>";
			out.println(html);
		} 
		catch (Exception e) {
			System.out.println("Error: " + e.toString());
			out.println("<p>Error al ejecutar la operación.</p>");
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		add(request, response);
	}
	
	

}
