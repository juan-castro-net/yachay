package org.usco.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class BaseDato {
	
	public Connection getConnection() {
		Connection con1 = null;
		
		String user = "web300";
		String password = "web300";
		String url = "jdbc:postgresql://localhost:5432/web300";
		String className = "org.postgresql.Driver";
		
		try {
			Class.forName(className);
			con1 = DriverManager.getConnection(url, user, password);
		}
		catch(Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return con1;
	}
}
